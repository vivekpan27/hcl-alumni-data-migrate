// exports.handler = (event, context, callback) => {
//     // TODO implement
//     callback(null, 'Hello from Lambda');
// };


var async = require('async');
var AWS = require('aws-sdk');
var gm = require('gm')
            .subClass({ imageMagick: true }); // Enable ImageMagick integration.
var util = require('util');

// constants
var MAX_WIDTH  = 100;
var MAX_HEIGHT = 100;

// get reference to s3 client
var s3 = new AWS.S3();

exports.handler = function(event, context, callback) {
  // Read options from the event.
  console.log("Reading options from the event:\n", util.inspect(event, {depth: 5}));
  var srcBucket = event.Records[0].s3.bucket.name;
  var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ""));
  var dstBucket = "hcl-alumni-details-prev";
  // var dstKey = "resized-" + srcKey;
  console.log(event);


  if (srcBucket == dstBucket) {
    callback("Source and destination buckets are the same.");
    return;
  }


}
